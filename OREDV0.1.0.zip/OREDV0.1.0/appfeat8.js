if (typeof DeroNFTApp !== 'undefined') {
    const ORDER_TYPES = {
        SELL: 'sell',
        BUY: 'buy'
    };

    /* ------------------------------------------------------------------
     * Image Handling Functions
     * Moved from appfeat1.js to reduce file size
     * ------------------------------------------------------------------ */
    
    // Handle image load - auto-pin IPFS images if enabled
    DeroNFTApp.prototype.handleImageLoad = function(imgElement, rawImageUrl) {
        if (!rawImageUrl || !rawImageUrl.startsWith('ipfs://')) {
            return;
        }
        
        try {
            const autoPinning = localStorage.getItem('ored_ipfs_auto_pinning') === 'true';
            if (autoPinning && this.pinIpfsContent) {
                // Pin in background (don't block rendering)
                this.pinIpfsContent(rawImageUrl).catch(err => {
                    // Silently fail - pinning is optional
                    console.debug('Auto-pin failed (non-critical):', err.message);
                });
            }
        } catch (e) {
            // Ignore errors
        }
    };
    
    // Handle image loading errors - try fallback gateways for IPFS URLs
    DeroNFTApp.prototype.handleImageError = function(imgElement, imageSrc) {
        if (!imgElement || !imageSrc) {
            imgElement.style.display = 'none';
            return;
        }
        
        // Check if this is an IPFS URL that failed
        if (imageSrc.includes('/ipfs/') && this.convertIpfsUrl) {
            // Try to get alternative gateway URLs
            const originalIpfsUrl = imageSrc;
            // Extract the IPFS hash and path from the failed URL
            const ipfsMatch = originalIpfsUrl.match(/\/ipfs\/([^?]+)/);
            if (ipfsMatch) {
                const hashAndPath = ipfsMatch[1];
                const ipfsUrl = `ipfs://${hashAndPath}`;
                
                // Get all gateway URLs to try
                const gatewayUrls = this.convertIpfsUrl(ipfsUrl, true);
                
                // Find current URL index
                const currentIndex = gatewayUrls.indexOf(originalIpfsUrl);
                if (currentIndex >= 0 && currentIndex < gatewayUrls.length - 1) {
                    // Try next gateway
                    const nextUrl = gatewayUrls[currentIndex + 1];
                    console.log(`🔄 [IPFS] Trying fallback gateway for ${hashAndPath}: ${nextUrl}`);
                    imgElement.src = nextUrl;
                    return; // Don't hide yet, try the next gateway
                }
            }
        }
        
        // If no more gateways to try, hide the image and show placeholder
        imgElement.style.display = 'none';
    };

    /* ------------------------------------------------------------------
     * Utility Functions
     * Moved from appfeat1.js to reduce file size
     * ------------------------------------------------------------------ */
    
    DeroNFTApp.prototype.getAssetDomKey = function(assetOrId) {
        let key = '';
        if (assetOrId && typeof assetOrId === 'object') {
            key = assetOrId.id
                || (assetOrId.scid && assetOrId.tokenId ? `${assetOrId.scid}_${assetOrId.tokenId}` : assetOrId.scid)
                || assetOrId.assetId;
        } else {
            key = assetOrId;
        }
        if (!key) return '';
        return String(key).replace(/[^0-9a-zA-Z_-]/g, '_');
    };

    DeroNFTApp.prototype.setActionLoading = function(asset, actionKey, isLoading) {
        if (!actionKey || typeof document === 'undefined') return;
        const domKey = this.getAssetDomKey(asset);
        if (!domKey) return;
        const selector = `.card-dropdown-item[data-action="${actionKey}"][data-asset-id="${domKey}"]`;
        const elements = document.querySelectorAll(selector);
        if (!elements || elements.length === 0) {
            return;
        }
        elements.forEach(el => {
            if (isLoading) {
                el.classList.add('loading');
            } else {
                el.classList.remove('loading');
            }
        });
    };

    DeroNFTApp.prototype.getAssetDisplayName = function(scid, tokenId) {
        if (tokenId !== undefined && tokenId !== null && tokenId !== '') {
            return `NFT #${tokenId}`;
        }
        const lowerScid = (scid || '').toLowerCase();
        const saved = (this.savedAssets || []).find(asset => (asset.scid || '').toLowerCase() === lowerScid);
        if (saved && saved.name) {
            return saved.name;
        }
        const searchSources = [this.lastSearchResults, this.lastCollectionResults];
        for (const source of searchSources) {
            if (Array.isArray(source)) {
                const match = source.find(asset => (asset.scid || '').toLowerCase() === lowerScid);
                if (match && match.name) {
                    return match.name;
                }
            }
        }
        if (scid) {
            return `Asset ${scid.substring(0, 8)}...`;
        }
        return 'NFT';
    };

    /* ------------------------------------------------------------------
     * Properties Modal Functions
     * Moved from appfeat1.js to reduce file size
     * ------------------------------------------------------------------ */
    
    DeroNFTApp.prototype.showProperties = function(indexOrId, context = 'search') {
        let asset = null;

        if (context === 'view' && typeof indexOrId === 'string') {
            asset = this.findAssetById(indexOrId);
        } else {
            const sourceLists = {
                search: this.lastSearchResults,
                collection: this.lastCollectionResults
            };
            const list = sourceLists[context] || [];
            asset = list[indexOrId];
        }

        if (!asset) {
            this.showError('Asset details not available yet');
            return;
        }

        const rows = [
            { label: 'Name', value: asset.name },
            { label: 'Type', value: asset.type || (asset.isCollection ? 'Collection' : 'NFT') },
            { label: 'SCID', value: asset.scid },
            { label: 'Token ID', value: asset.tokenId },
            { label: 'Asset ID', value: asset.id },
            { label: 'Collection', value: asset.collection_name },
            { label: 'Collection SCID', value: asset.collection_scid },
            { label: 'Owner', value: asset.owner },
            { label: 'Minter', value: asset.minter },
            { label: 'Contract Type', value: asset.contractType },
            { label: 'Description', value: asset.description }
        ].filter(row => row.value);

        const attributesHtml = asset.attributes ? `
            <div class="property-section">
                <h4>Attributes</h4>
                <div class="property-grid">
                    ${Object.entries(asset.attributes).map(([key, value]) => `
                        <div class="property-row">
                            <span class="property-label">${key}</span>
                            <span class="property-value">${value}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : '';

        const escapeHtml = (value) => {
            return String(value)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
        };

        const metadataHtml = asset.metadata ? `
            <div class="property-section">
                <h4>Metadata</h4>
                <pre class="metadata-block">${escapeHtml(
                    typeof asset.metadata === 'string'
                        ? asset.metadata
                        : JSON.stringify(asset.metadata, null, 2)
                )}</pre>
            </div>
        ` : '';

        const detailsHtml = rows.length > 0 ? `
            <div class="property-section">
                <h4>Details</h4>
                <div class="property-grid">
                    ${rows.map(row => `
                        <div class="property-row">
                            <span class="property-label">${row.label}</span>
                            <span class="property-value">${row.value}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : '';

        const modalHtml = `
            <div class="modal active" id="propertiesModal" onclick="if(event.target.id === 'propertiesModal') app.hideProperties()">
                <div class="modal-content" style="max-width: 720px; max-height: 90vh; overflow-y: auto;">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                        <h2 style="margin:0;">${asset.name || 'Asset Properties'}</h2>
                        <button class="btn btn-secondary" onclick="app.hideProperties()">
                            <i class="fas fa-times"></i> Close
                        </button>
                    </div>
                    ${asset.image ? `
                        <div style="text-align:center;margin-bottom:20px;">
                            <img src="${asset.image}" alt="${asset.name || 'Asset'}" style="max-width:100%;max-height:280px;border-radius:12px;" onerror="this.style.display='none'">
                        </div>
                    ` : ''}
                    ${detailsHtml}
                    ${attributesHtml}
                    ${metadataHtml}
                </div>
            </div>
        `;

        const existing = document.getElementById('propertiesModal');
        if (existing) {
            existing.remove();
        }

        document.body.insertAdjacentHTML('beforeend', modalHtml);
    };

    DeroNFTApp.prototype.showPropertiesById = function(assetId, context = 'view') {
        this.showProperties(assetId, context);
    };

    DeroNFTApp.prototype.hideProperties = function() {
        const modal = document.getElementById('propertiesModal');
        if (modal) {
            modal.remove();
        }
    };

    /* ------------------------------------------------------------------
     * Simple-Gnomon WebSocket Integration
     * Moved from appfeat7.js to reduce file size
     * ------------------------------------------------------------------ */
    
    // Get indexed SCIDs from simple-gnomon WebSocket
    // simple-gnomon uses WebSocket at ws://127.0.0.1:9190/ws
    DeroNFTApp.prototype.getIndexedScidsFromSimpleGnomon = async function(wsUrl) {
        return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                if (ws) {
                    ws.close();
                }
                reject(new Error('WebSocket connection timeout (10 seconds)'));
            }, 10000); // 10 second timeout
            
            let ws = null;
            try {
                ws = new WebSocket(wsUrl);
                
                ws.onopen = () => {
                    console.log('✅ [simple-gnomon] WebSocket connected to', wsUrl);
                    // Request indexed SCIDs - try different message formats
                    // Format 1: JSON-RPC style
                    const request1 = {
                        jsonrpc: '2.0',
                        id: 1,
                        method: 'get_indexed_scids',
                        params: {}
                    };
                    ws.send(JSON.stringify(request1));
                    
                    // Also try alternative formats after a short delay if first doesn't work
                    setTimeout(() => {
                        if (ws && ws.readyState === WebSocket.OPEN) {
                            // Format 2: Simple command
                            const request2 = { command: 'get_indexed_scids' };
                            ws.send(JSON.stringify(request2));
                        }
                    }, 1000);
                };
                
                ws.onmessage = (event) => {
                    try {
                        const response = JSON.parse(event.data);
                        console.log('📨 [simple-gnomon] Received response:', response);
                        
                        // Handle different response formats
                        let scids = [];
                        if (response.result && Array.isArray(response.result)) {
                            scids = response.result;
                        } else if (response.indexedscs && Array.isArray(response.indexedscs)) {
                            scids = response.indexedscs;
                        } else if (response.scids && Array.isArray(response.scids)) {
                            scids = response.scids;
                        } else if (response.data && Array.isArray(response.data)) {
                            scids = response.data;
                        } else if (Array.isArray(response)) {
                            scids = response;
                        } else if (response.result && typeof response.result === 'object') {
                            // Try to extract array from nested result
                            const nested = response.result.indexedscs || response.result.scids || response.result.data;
                            if (Array.isArray(nested)) {
                                scids = nested;
                            }
                        }
                        
                        if (scids.length > 0) {
                            clearTimeout(timeout);
                            ws.close();
                            console.log(`✅ [simple-gnomon] Found ${scids.length} indexed SCIDs`);
                            resolve(scids);
                        } else {
                            // Response received but no SCIDs found - might be an error or different format
                            console.warn('⚠️ [simple-gnomon] Response received but no SCIDs found in expected format:', response);
                        }
                    } catch (parseError) {
                        console.error('❌ [simple-gnomon] Failed to parse response:', parseError, event.data);
                        // Don't reject immediately - might get another message
                    }
                };
                
                ws.onerror = (error) => {
                    console.error('❌ [simple-gnomon] WebSocket error:', error);
                    clearTimeout(timeout);
                    if (ws) {
                        ws.close();
                    }
                    reject(new Error(`WebSocket error: ${error.message || 'Connection failed'}`));
                };
                
                ws.onclose = (event) => {
                    clearTimeout(timeout);
                    if (!event.wasClean && event.code !== 1000) {
                        console.error(`❌ [simple-gnomon] WebSocket closed unexpectedly: code ${event.code}, reason: ${event.reason || 'unknown'}`);
                        reject(new Error(`WebSocket closed unexpectedly: code ${event.code}`));
                    } else if (event.wasClean) {
                        console.log('✅ [simple-gnomon] WebSocket closed cleanly');
                    }
                };
            } catch (error) {
                clearTimeout(timeout);
                if (ws) {
                    ws.close();
                }
                reject(error);
            }
        });
    };

    /* ------------------------------------------------------------------
     * IPFS and GitHub URL Conversion Functions
     * Moved from appcore.js to reduce file size
     * ------------------------------------------------------------------ */
    
    // Convert IPFS URL to gateway URL
    // Supports formats: ipfs://QmHash..., ipfs://ipfs/QmHash..., /ipfs/QmHash...
    // Returns an array of gateway URLs to try (for fallback support)
    DeroNFTApp.prototype.convertIpfsUrl = function(ipfsUrl, returnArray = false) {
        if (!ipfsUrl || typeof ipfsUrl !== 'string') {
            return returnArray ? [] : ipfsUrl;
        }
        
        const trimmed = ipfsUrl.trim();
        
        // If already an HTTP URL, return as-is
        if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
            return returnArray ? [trimmed] : trimmed;
        }
        
        // If it's a data URL, return as-is
        if (trimmed.startsWith('data:')) {
            return returnArray ? [trimmed] : trimmed;
        }
        
        // Extract IPFS hash from various formats
        let ipfsHash = null;
        
        // Format: ipfs://QmHash... or ipfs://ipfs/QmHash...
        if (trimmed.startsWith('ipfs://')) {
            ipfsHash = trimmed.replace(/^ipfs:\/\/(ipfs\/)?/, '');
        }
        // Format: /ipfs/QmHash...
        else if (trimmed.startsWith('/ipfs/')) {
            ipfsHash = trimmed.replace(/^\/ipfs\//, '');
        }
        // Format: QmHash... (just the hash)
        else if (/^Qm[1-9A-HJ-NP-Za-km-z]{44}$/.test(trimmed) || /^baf[a-z0-9]{56,}$/.test(trimmed)) {
            ipfsHash = trimmed;
        }
        
        // If we found a hash, convert to gateway URLs
        if (ipfsHash) {
            // Preserve the full path after the hash (e.g., /302.png)
            // Remove query params but keep the path
            const hashAndPath = ipfsHash.split('?')[0]; // Keep full path, just remove query params
            
            // Get saved gateway preferences
            let preferredGateway = null;
            let localGateway = this.localIpfsGateway;
            
            try {
                // Check for local gateway first (highest priority)
                if (!localGateway) {
                    localGateway = localStorage.getItem('ored_local_ipfs_gateway');
                }
                
                // Check for custom gateway (secondary priority)
                const savedGateway = localStorage.getItem('ored_ipfs_gateway');
                if (savedGateway) {
                    preferredGateway = savedGateway.endsWith('/') ? savedGateway : savedGateway + '/';
                }
            } catch (e) {
                // Ignore localStorage errors
            }
            
            // Build list of gateways to try (local first, then preferred, then public fallbacks)
            const gatewaysToTry = [];
            
            // 1. Local IPFS node (if configured) - highest priority
            if (localGateway) {
                const normalized = localGateway.trim();
                const localUrl = normalized.endsWith('/ipfs/') ? normalized : 
                                (normalized.endsWith('/') ? normalized + 'ipfs/' : normalized + '/ipfs/');
                gatewaysToTry.push(localUrl);
            }
            
            // 2. Custom preferred gateway (if set and different from local)
            if (preferredGateway && (!localGateway || !preferredGateway.includes(localGateway.replace(/\/ipfs\/$/, '')))) {
                gatewaysToTry.push(preferredGateway);
            }
            
            // 3. Add all default public gateways (excluding ones already added)
            for (const gateway of this.ipfsGateways) {
                const gatewayBase = gateway.replace(/\/ipfs\/$/, '');
                const alreadyAdded = gatewaysToTry.some(g => g.includes(gatewayBase));
                if (!alreadyAdded) {
                    gatewaysToTry.push(gateway);
                }
            }
            
            // Normalize gateways (ensure they end with /ipfs/)
            const normalizedGateways = gatewaysToTry.map(gateway => {
                if (!gateway.endsWith('/ipfs/')) {
                    return gateway.endsWith('/') ? gateway + 'ipfs/' : gateway + '/ipfs/';
                }
                return gateway;
            });
            
            // Generate URLs for all gateways
            const gatewayUrls = normalizedGateways.map(gateway => gateway + hashAndPath);
            
            return returnArray ? gatewayUrls : gatewayUrls[0]; // Return first URL or all URLs
        }
        
        // If we couldn't parse it, return original
        return returnArray ? [ipfsUrl] : ipfsUrl;
    };
    
    // Set local IPFS gateway (saves to localStorage)
    DeroNFTApp.prototype.setLocalIpfsGateway = function(gatewayUrl) {
        const normalized = gatewayUrl ? gatewayUrl.trim().replace(/\/+$/, '') : '';
        
        try {
            if (normalized) {
                localStorage.setItem('ored_local_ipfs_gateway', normalized);
                this.localIpfsGateway = normalized;
            } else {
                localStorage.removeItem('ored_local_ipfs_gateway');
                this.localIpfsGateway = null;
            }
            return true;
        } catch (e) {
            console.warn('Failed to save local IPFS gateway to localStorage:', e);
            return false;
        }
    };
    
    // Set custom IPFS gateway (saves to localStorage) - for non-local gateways
    DeroNFTApp.prototype.setIpfsGateway = function(gatewayUrl) {
        if (!gatewayUrl || typeof gatewayUrl !== 'string') {
            return false;
        }
        
        const normalized = gatewayUrl.trim().replace(/\/+$/, ''); // Remove trailing slashes
        
        try {
            localStorage.setItem('ored_ipfs_gateway', normalized);
            // Update current gateway index if it matches one of our defaults
            const index = this.ipfsGateways.findIndex(g => normalized.includes(g.replace(/\/ipfs\/$/, '')));
            if (index >= 0) {
                this.currentIpfsGatewayIndex = index;
            }
            return true;
        } catch (e) {
            console.warn('Failed to save IPFS gateway to localStorage:', e);
            return false;
        }
    };
    
    // Get current IPFS gateway URL (returns local if set, otherwise public)
    DeroNFTApp.prototype.getIpfsGateway = function() {
        try {
            if (this.localIpfsGateway) {
                return this.localIpfsGateway.endsWith('/') ? this.localIpfsGateway : this.localIpfsGateway + '/';
            }
            const savedGateway = localStorage.getItem('ored_ipfs_gateway');
            if (savedGateway) {
                return savedGateway.endsWith('/') ? savedGateway : savedGateway + '/';
            }
        } catch (e) {
            // Ignore localStorage errors
        }
        return this.ipfsGateways[this.currentIpfsGatewayIndex];
    };
    
    // Pin IPFS content via IPFS API
    DeroNFTApp.prototype.pinIpfsContent = async function(ipfsHash) {
        let apiUrl = null;
        try {
            apiUrl = localStorage.getItem('ored_ipfs_api_url') || 'http://localhost:5001';
        } catch (e) {
            apiUrl = 'http://localhost:5001';
        }
        
        // Extract hash from full IPFS URL if needed
        let hash = ipfsHash;
        if (hash.includes('/ipfs/')) {
            const match = hash.match(/\/ipfs\/([^?\/]+)/);
            if (match) {
                hash = match[1];
            }
        } else if (hash.startsWith('ipfs://')) {
            hash = hash.replace(/^ipfs:\/\/(ipfs\/)?/, '').split('/')[0];
        }
        
        // Call IPFS API to pin
        try {
            const response = await fetch(`${apiUrl}/api/v0/pin/add?arg=${hash}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            
            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`IPFS API error: ${response.status} - ${errorText}`);
            }
            
            const result = await response.json();
            console.log('✅ [IPFS] Pinned content:', hash, result);
            return result;
        } catch (error) {
            console.error('❌ [IPFS] Failed to pin content:', error);
            throw error;
        }
    };
    
    // Test IPFS connection
    DeroNFTApp.prototype.testIpfsConnection = async function() {
        let apiUrl = null;
        try {
            apiUrl = localStorage.getItem('ored_ipfs_api_url') || 'http://localhost:5001';
        } catch (e) {
            apiUrl = 'http://localhost:5001';
        }
        
        try {
            const response = await fetch(`${apiUrl}/api/v0/version`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });
            
            if (!response.ok) {
                throw new Error(`IPFS API error: ${response.status}`);
            }
            
            const version = await response.json();
            return { success: true, version: version.Version || 'unknown' };
        } catch (error) {
            return { success: false, error: error.message };
        }
    };
    
    // Convert GitHub URLs to raw.githubusercontent.com format for direct image access
    DeroNFTApp.prototype.convertGitHubUrl = function(githubUrl) {
        if (!githubUrl || typeof githubUrl !== 'string') {
            return githubUrl;
        }
        
        const trimmed = githubUrl.trim();
        
        // If already a raw.githubusercontent.com URL, return as-is
        if (trimmed.includes('raw.githubusercontent.com')) {
            return trimmed;
        }
        
        // Convert regular GitHub URLs to raw format
        // Pattern: https://github.com/user/repo/blob/branch/path/to/file.png
        // Becomes: https://raw.githubusercontent.com/user/repo/branch/path/to/file.png
        const githubMatch = trimmed.match(/^https?:\/\/github\.com\/([^\/]+)\/([^\/]+)\/(?:blob|tree)\/([^\/]+)\/(.+)$/i);
        if (githubMatch) {
            const [, user, repo, branch, path] = githubMatch;
            return `https://raw.githubusercontent.com/${user}/${repo}/${branch}/${path}`;
        }
        
        // Also handle github.com URLs without blob/tree (direct file links)
        const directMatch = trimmed.match(/^https?:\/\/github\.com\/([^\/]+)\/([^\/]+)\/(?:raw|master|main)\/(.+)$/i);
        if (directMatch) {
            const [, user, repo, path] = directMatch;
            return `https://raw.githubusercontent.com/${user}/${repo}/master/${path}`;
        }
        
        // If it's a GitHub URL but doesn't match patterns, try to construct raw URL
        if (trimmed.includes('github.com')) {
            // Try to extract user/repo and construct raw URL
            const repoMatch = trimmed.match(/github\.com\/([^\/]+)\/([^\/]+)/i);
            if (repoMatch) {
                const [, user, repo] = repoMatch;
                // Default to master branch and try to extract path
                const pathMatch = trimmed.match(/(?:blob|tree)\/[^\/]+\/(.+)$/i);
                const path = pathMatch ? pathMatch[1] : '';
                if (path) {
                    return `https://raw.githubusercontent.com/${user}/${repo}/master/${path}`;
                }
            }
        }
        
        // Return original URL if no conversion needed
        return trimmed;
    };

    /* ------------------------------------------------------------------
     * Order Management Utility Functions
     * Moved from appfeat3.js to reduce file size
     * ------------------------------------------------------------------ */
    
    DeroNFTApp.prototype.getOrderStorageKey = function(type) {
        const address = (this.currentAddress || 'anonymous').toLowerCase();
        return `ored_${type}_orders_${address}`;
    };

    DeroNFTApp.prototype.getLocalOrders = function(type) {
        try {
            const raw = localStorage.getItem(this.getOrderStorageKey(type));
            if (!raw) return [];
            const parsed = JSON.parse(raw);
            return Array.isArray(parsed) ? parsed : [];
        } catch (error) {
            return [];
        }
    };

    DeroNFTApp.prototype.saveLocalOrders = function(type, orders) {
        try {
            localStorage.setItem(this.getOrderStorageKey(type), JSON.stringify(orders || []));
        } catch (error) {
            // Ignore save errors
        }
    };

    DeroNFTApp.prototype.buildSavedAssetIndex = function() {
        const index = {};
        const assets = Array.isArray(this.savedAssets) ? this.savedAssets : [];
        assets.forEach(asset => {
            if (!asset || !asset.scid) return;
            const key = asset.scid.toLowerCase();
            if (!index[key]) {
                index[key] = {
                    scid: asset.scid,
                    entries: []
                };
            }
            index[key].entries.push(asset);
        });
        return index;
    };

    DeroNFTApp.prototype.getTrackedAssetScids = function() {
        const tracked = new Set();
        const addFromList = (list) => {
            if (!Array.isArray(list)) return;
            list.forEach(asset => {
                if (asset && asset.scid) {
                    tracked.add(asset.scid.toLowerCase());
                }
            });
        };
        addFromList(this.savedAssets);
        const cache = this.assetsCache?.value;
        if (Array.isArray(cache)) {
            addFromList(cache);
        } else if (cache) {
            addFromList(cache.nfts);
            addFromList(cache.nfas);
        }
        addFromList(this.lastSearchResults);
        addFromList(this.lastCollectionResults);
        return tracked;
    };

    /* ------------------------------------------------------------------
     * Order Modal Functions
     * Moved from appfeat3.js to reduce file size
     * ------------------------------------------------------------------ */
    
    DeroNFTApp.prototype.showAssetSellOrderModal = async function(scid, tokenId, assetName) {
        const assetDetails = this.prepareAssetForOrder ? await this.prepareAssetForOrder(scid, tokenId, assetName) : { scid, tokenId, name: assetName };
        const resolvedName = (assetDetails && assetDetails.name) || assetName || (scid ? `NFT ${scid.substring(0, 8)}...` : 'NFT');
        const preppedDetails = assetDetails || null;
        const isArtAsset = this.isArtificerAsset ? this.isArtificerAsset(preppedDetails) : false;
        const isG45Asset = this.isG45Asset ? this.isG45Asset(preppedDetails) : true;
        const assetImage = (preppedDetails && preppedDetails.image) || (this.getPlaceholderImage ? this.getPlaceholderImage() : '');
        
        // Remove existing modal if any
        const existing = document.getElementById('assetSellOrderModal');
        if (existing) {
            existing.remove();
        }
        
        const modalHtml = `
            <div class="modal active" id="assetSellOrderModal" onclick="if(event.target.id === 'assetSellOrderModal') app.hideAssetSellOrderModal()">
                <div class="modal-content" style="max-width: 500px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h2 style="margin: 0;">Create Sell Order</h2>
                        <button class="btn btn-secondary" onclick="app.hideAssetSellOrderModal()" style="padding: 8px 16px;">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    ${assetImage ? `<img src="${assetImage}" alt="${resolvedName}" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px; margin-bottom: 15px;" onerror="this.style.display='none'">` : ''}
                    <div style="margin-bottom: 15px; color: #aaa; font-size: 0.9rem;">
                        <p style="margin: 0;"><strong>Asset:</strong> ${resolvedName}</p>
                        <p style="margin: 0;"><strong>SCID:</strong> ${scid}</p>
                        <p style="margin: 0;"><strong>Type:</strong> ${isArtAsset ? 'NFA' : isG45Asset ? 'NFT' : 'Asset'}</p>
                    </div>
                    <form id="assetSellOrderForm" onsubmit="app.submitAssetSellOrder(event, '${scid}', '${tokenId || ''}', '${resolvedName.replace(/'/g, "\\'")}', ${isArtAsset}, ${isG45Asset}); return false;">
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label for="assetSellPrice" style="display: block; margin-bottom: 5px; font-weight: bold;">Price (DERO):</label>
                            <input 
                                type="number" 
                                id="assetSellPrice" 
                                class="form-input" 
                                placeholder="10" 
                                step="0.000001"
                                min="0.000001"
                                required
                                style="width: 100%;"
                            >
                        </div>
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label for="assetSellDuration" style="display: block; margin-bottom: 5px; font-weight: bold;">Duration (hours):</label>
                            <input 
                                type="number" 
                                id="assetSellDuration" 
                                class="form-input" 
                                placeholder="72" 
                                value="72"
                                min="1"
                                required
                                style="width: 100%;"
                            >
                        </div>
                        <div style="display: flex; gap: 10px;">
                            <button type="button" class="btn btn-secondary" onclick="app.hideAssetSellOrderModal()" style="flex: 1;">
                                Cancel
                            </button>
                            <button type="submit" class="btn btn-primary" style="flex: 1;">
                                <i class="fas fa-arrow-down"></i> Create On-Chain Order
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
        // Focus on price input
        setTimeout(() => {
            const input = document.getElementById('assetSellPrice');
            if (input) input.focus();
        }, 100);
    };

    DeroNFTApp.prototype.hideAssetSellOrderModal = function() {
        const modal = document.getElementById('assetSellOrderModal');
        if (modal) {
            modal.remove();
        }
    };

    DeroNFTApp.prototype.showAssetBuyOrderModal = async function(scid, tokenId, assetName) {
        const assetDetails = this.prepareAssetForOrder ? await this.prepareAssetForOrder(scid, tokenId, assetName) : null;
        const resolvedName = (assetDetails && assetDetails.name) || assetName || (scid ? `NFT ${scid.substring(0, 8)}...` : 'NFT');
        const isArtAsset = this.isArtificerAsset ? this.isArtificerAsset(assetDetails) : false;
        const isG45Asset = this.isG45Asset ? this.isG45Asset(assetDetails) : true;
        const assetImage = (assetDetails && assetDetails.image) || (this.getPlaceholderImage ? this.getPlaceholderImage() : '');
        
        // Remove existing modal if any
        const existing = document.getElementById('assetBuyOrderModal');
        if (existing) {
            existing.remove();
        }
        
        const modalHtml = `
            <div class="modal active" id="assetBuyOrderModal" onclick="if(event.target.id === 'assetBuyOrderModal') app.hideAssetBuyOrderModal()">
                <div class="modal-content" style="max-width: 500px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                        <h2 style="margin: 0;">Create Buy Order</h2>
                        <button class="btn btn-secondary" onclick="app.hideAssetBuyOrderModal()" style="padding: 8px 16px;">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    ${assetImage ? `<img src="${assetImage}" alt="${resolvedName}" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px; margin-bottom: 15px;" onerror="this.style.display='none'">` : ''}
                    <div style="margin-bottom: 15px; color: #aaa; font-size: 0.9rem;">
                        <p style="margin: 0;"><strong>Asset:</strong> ${resolvedName}</p>
                        <p style="margin: 0;"><strong>SCID:</strong> ${scid}</p>
                        <p style="margin: 0;"><strong>Type:</strong> ${isArtAsset ? 'NFA' : isG45Asset ? 'NFT' : 'Asset'}</p>
                    </div>
                    <form id="assetBuyOrderForm" onsubmit="app.submitAssetBuyOrder(event, '${scid}', '${tokenId || ''}', '${resolvedName.replace(/'/g, "\\'")}', ${isArtAsset}, ${isG45Asset}); return false;">
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label for="assetBuyPrice" style="display: block; margin-bottom: 5px; font-weight: bold;">Buy Offer (DERO):</label>
                            <input 
                                type="number" 
                                id="assetBuyPrice" 
                                class="form-input" 
                                placeholder="5" 
                                value="5"
                                step="0.000001"
                                min="0.000001"
                                required
                                style="width: 100%;"
                            >
                            <small style="color: #aaa; font-size: 0.85rem;">This amount will be escrowed in the marketplace</small>
                        </div>
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label for="assetBuyDuration" style="display: block; margin-bottom: 5px; font-weight: bold;">Duration (hours):</label>
                            <input 
                                type="number" 
                                id="assetBuyDuration" 
                                class="form-input" 
                                placeholder="48" 
                                value="48"
                                min="1"
                                required
                                style="width: 100%;"
                            >
                        </div>
                        <div style="display: flex; gap: 10px;">
                            <button type="button" class="btn btn-secondary" onclick="app.hideAssetBuyOrderModal()" style="flex: 1;">
                                Cancel
                            </button>
                            <button type="submit" class="btn btn-primary" style="flex: 1;">
                                <i class="fas fa-arrow-up"></i> Create On-Chain Order
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
        // Focus on price input
        setTimeout(() => {
            const input = document.getElementById('assetBuyPrice');
            if (input) input.focus();
        }, 100);
    };

    DeroNFTApp.prototype.hideAssetBuyOrderModal = function() {
        const modal = document.getElementById('assetBuyOrderModal');
        if (modal) {
            modal.remove();
        }
    };

    DeroNFTApp.prototype.prepareAssetForOrder = async function(scid, tokenId, assetName) {
        if (!scid) {
            return {
                scid: '',
                tokenId: tokenId || 0,
                name: assetName || 'NFT'
            };
        }
        try {
            const asset = this.queryAssetBySCID ? await this.queryAssetBySCID(scid) : null;
            if (asset && !asset.error) {
                return {
                    scid: asset.scid || scid,
                    tokenId: asset.tokenId || tokenId || 0,
                    name: asset.name || assetName || 'NFT',
                    image: asset.image || null
                };
            }
        } catch (e) {
            // Ignore query errors
        }
        return {
            scid: scid,
            tokenId: tokenId || 0,
            name: assetName || 'NFT'
        };
    };

    /* ------------------------------------------------------------------
     * Artificer Marketplace Functions
     * ------------------------------------------------------------------ */

    DeroNFTApp.prototype.startArtificerSale = async function(asset, priceDero, durationHours) {
        if (!this.callContractEntry) {
            throw new Error('Wallet connection not available for Artificer sale.');
        }
        
        // Normalize SCID to lowercase to ensure wallet can decode it properly
        // The wallet needs SCIDs in lowercase format to resolve them correctly
        const normalizedScid = asset.scid.toLowerCase().trim();
        
        // Check initial balance before transaction
        let initialBalance = 0;
        try {
            const balanceCheck = await this.deroWallet?.ws?.sendRequest('GetBalance', { scid: normalizedScid });
            initialBalance = balanceCheck?.result?.balance || 0;
            if (initialBalance < 1) {
                this.showError('You do not own this NFA. Balance is less than 1 atomic unit.');
                return;
            }
        } catch (balanceError) {
            // Continue anyway - let the contract reject if balance is insufficient
        }
        
        // Validate NFA SCID exists and ensure wallet has it in state tree
        // This helps the wallet recognize the SCID before using it as a transfer destination
        try {
            const scResult = await this.deroWallet.ws.getSC(normalizedScid);
            if (scResult && scResult.error) {
                // Don't throw - let the contract call proceed
            } else if (scResult && (scResult.result || scResult.status === 'OK')) {
                // Delay to ensure wallet has processed the SCID in its state tree
                // The wallet needs time to index the SCID before it can be used as a transfer destination
                await new Promise(resolve => setTimeout(resolve, 300));
            }
        } catch (error) {
            // Ignore SC validation errors
        }
        
        // For ART-NFA-MS1, the NFA contract acts as its own marketplace
        // The Start function requires:
        // - 1 atomic unit of the NFA asset to be transferred to the NFA contract itself
        // - Price in DERO (atomic units)
        // - Duration in hours
        const priceAtomic = this.deroToAtomic ? this.deroToAtomic(priceDero) : Math.floor(priceDero * 100000);
        
        // Format per DERO docs: transfers array contains scid (asset SCID) and burn amount
        // TRANSFER DESTINATION: When using 'burn' with 'scid', asset automatically goes to contract in main scid param
        // Main scid parameter (normalizedScid) = NFA contract SCID = destination for the asset
        // The 1 atomic unit goes to the NFA contract itself
        // Reference: https://github.com/deroproject/documentation/blob/master/DVMDOCS/examples/assetexchange/example.sh
        // Asset transfers with scid + burn do NOT need destination field - asset goes to contract automatically
        const transfers = [{
            scid: normalizedScid,         // The SCID of the NFA asset being sent
            burn: 1                      // 1 atomic unit (burned to NFA contract in main scid param)
        }];
        
        // Contract expects: Start(listType String, duration Uint64, startPrice Uint64, charityDonateAddr String, charityDonatePerc Uint64)
        // Reference: https://github.com/civilware/artificer-nfa-standard/blob/main/ART-NFA-MS1/README.md#start
        // Note: ART-NFA-MS1 requires SC_ACTION and SC_ID parameters per official documentation
        // SC_ACTION: 0 (standard action)
        // SC_ID: The contract SCID (in hex format, not address format)
        // Note: callContractEntry automatically adds 'entrypoint', so we don't add it here
        const scRpc = [
            { name: 'listType', datatype: 'S', value: 'sale' },  // First parameter: listType (String)
            { name: 'duration', datatype: 'U', value: durationHours },  // Second parameter: duration (Uint64)
            { name: 'startPrice', datatype: 'U', value: priceAtomic },  // Third parameter: startPrice (Uint64)
            { name: 'charityDonateAddr', datatype: 'S', value: '' },  // Fourth parameter: charityDonateAddr (String) - empty string for no charity
            { name: 'charityDonatePerc', datatype: 'U', value: 0 },  // Fifth parameter: charityDonatePerc (Uint64) - 0 for no charity donation
            { name: 'SC_ACTION', datatype: 'U', value: 0 },  // Required by ART-NFA-MS1 standard
            { name: 'SC_ID', datatype: 'H', value: normalizedScid }  // Required by ART-NFA-MS1 standard - SCID in hex format
        ];
        
        let response;
        try {
            response = await this.callContractEntry(normalizedScid, 'Start', scRpc, { transfers: transfers });
        } catch (error) {
            this.logTransactionError?.('NFA Start Sale', error, {
                scid: normalizedScid,
                entrypoint: 'Start',
                assetScid: normalizedScid,
                price: priceAtomic,
                duration: durationHours,
                transfers
            });
            return;
        }

        // Extract txid - handle both response formats
        const txid = response?.result?.txid ?? response?.txid ?? response?.txid;
        const returnValue = response?.result?.value ?? response?.value;
        
        if (!txid) {
            this.showError('Transaction failed: No transaction ID received. Please check wallet connection and try again.');
            // Return null/undefined so submitAssetSellOrder knows it failed
            return null;
        }
        
        if (returnValue !== undefined && returnValue !== null && returnValue !== 0) {
            const errorMessages = {
                1: 'Invalid price (must be > 0)',
                2: 'Invalid duration',
                3: 'Contract not initialized',
                4: 'Insufficient asset balance (must have 1 atomic unit)',
                5: 'Asset already listed'
            };
            const errorMsg = errorMessages[returnValue] || `Contract returned error code: ${returnValue}`;
            const contractError = new Error(`NFA listing rejected by contract: ${errorMsg}`);
            this.logTransactionError?.('NFA Start Sale - Contract Rejection', contractError, {
                scid: normalizedScid,
                entrypoint: 'Start',
                returnValue,
                txid,
                response,
                errorMessage: errorMsg
            });
            return;
        }

        // IMPORTANT: Check balance and transaction return value after transaction to verify it succeeded
        // Wait a moment for the transaction to be processed
        if (txid) {
            // Wait for transaction to be mined
            await new Promise(resolve => setTimeout(resolve, 2000)); // Wait 2 seconds
            
            // Check transaction return value if available
            try {
                const txCheck = await this.deroWallet?.ws?.sendRequest('DERO.GetTransaction', { 
                    txs_hashes: [txid], 
                    decode_as_json: true 
                });
                const txResult = txCheck?.result?.txs?.[0];
                if (txResult?.payload_rpc) {
                    const returnParam = txResult.payload_rpc.find(p => p.name === 'return' || p.datatype === 'return');
                    if (returnParam && returnParam.value !== undefined && returnParam.value !== null && returnParam.value !== 0) {
                        const errorMessages = {
                            1: 'Invalid price (must be > 0)',
                            2: 'Invalid duration',
                            3: 'Contract not initialized',
                            4: 'Insufficient asset balance (must have 1 atomic unit)',
                            5: 'Asset already listed'
                        };
                        const errorMsg = errorMessages[returnParam.value] || `Contract returned error code: ${returnParam.value}`;
                        this.showError(`NFA listing rejected: ${errorMsg}. Transaction: ${txid}`);
                        return;
                    }
                }
            } catch (txError) {
                // Ignore transaction check errors
            }
            
            // Check balance to see if asset was transferred
            try {
                const balanceCheck = await this.deroWallet?.ws?.sendRequest('GetBalance', { scid: normalizedScid });
                const newBalance = balanceCheck?.result?.balance || 0;
                
                // For NFAs, starting a sale transfers 1 atomic unit to the contract
                // So balance should decrease by 1 (from initialBalance to initialBalance - 1)
                if (newBalance >= initialBalance) {
                    this.showError(`Transaction submitted but asset balance did not decrease (was ${initialBalance}, now ${newBalance}). The contract may have rejected the transfer. Check the transaction status or try again.`);
                    return;
                }
            } catch (balanceError) {
                // Ignore balance verification errors
            }
        }

        if (txid) {
            this.showNotification(`NFA listing transaction submitted (txid: ${txid}). Waiting for confirmation...`, 'info', 0); // 0 duration for sticky
            
            let confirmed = false;
            const maxAttempts = 30; // Check for up to 30 seconds
            for (let i = 0; i < maxAttempts; i++) {
                await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
                try {
                    const scResult = await this.deroWallet.ws.getSC(normalizedScid);
                    const scData = scResult?.result || scResult;
                    const stringKeys = scData?.stringkeys || {};
                    const uint64Keys = scData?.uint64keys || {};

                    const decS = (key) => {
                        const raw = stringKeys[key];
                        if (!raw) return '';
                        return this.decodeHexString ? this.decodeHexString(raw) : raw;
                    };
                    const decU = (key) => {
                        if (uint64Keys[key] !== undefined) {
                            const v = parseInt(uint64Keys[key], 10);
                            return Number.isNaN(v) ? 0 : v;
                        }
                        const raw = stringKeys[key];
                        if (!raw) return 0;
                        const d = this.decodeHexString ? this.decodeHexString(raw) : raw;
                        const p = parseInt(d, 10);
                        return Number.isNaN(p) ? 0 : p;
                    };
                    
                    const active = decU('active');
                    const scBalance = decU('scBalance');
                    const listType = decS('listType');
                    const owner = decS('owner');
                    const currentAddress = this.currentAddress || '';
                    const addressMatches = (addr) => {
                        if (!addr) return false;
                        const normalize = (a) => {
                            if (!a) return '';
                            const lower = a.toLowerCase();
                            if (lower.startsWith('dero1')) return lower;
                            if (lower.startsWith('deto1')) return 'dero' + lower.substring(4);
                            return lower;
                        };
                        return normalize(addr) === normalize(currentAddress) || 
                               addr.toLowerCase() === currentAddress.toLowerCase() ||
                               addr.toLowerCase().substring(0, 20) === currentAddress.toLowerCase().substring(0, 20);
                    };
                    const isOwner = owner && addressMatches(owner);

                    // Confirm listing if active, or escrowed and owner matches, or listing data exists and owner matches
                    if ((active === 1 && scBalance === 1 && (listType === 'sale' || listType === 'auction')) ||
                        (isOwner && scBalance > 0) ||
                        (isOwner && (listType === 'sale' || listType === 'auction'))) {
                        confirmed = true;
                        break;
                    }
                } catch (error) {
                    // Ignore confirmation check errors
                }
            }
            
            if (confirmed) {
                this.showSuccess(`✅ NFA listing confirmed on-chain! (txid: ${txid})`);
            } else {
                this.showSuccess(`NFA listing transaction sent (txid: ${txid}). Listing may take a few moments to appear.`);
            }
            
            // Refresh asset status after a delay to detect the listing
            setTimeout(async () => {
                if (this.loadAssets) {
                    await this.loadAssets(true);
                }
                if (this.loadSellOrders) {
                    await this.loadSellOrders(true); // Force refresh sell orders
                }
            }, 2000); // Wait 2 seconds for block confirmation
        } else {
            this.showSuccess('NFA listing request sent. Please approve in wallet if prompted.');
        }
        
        return response;
    };

    DeroNFTApp.prototype.startArtificerBuyNow = async function(asset, priceDero) {
        if (!this.callContractEntry) {
            throw new Error('Wallet connection not available for Artificer buy.');
        }
        
        const normalizedScid = asset.scid.toLowerCase().trim();
        const priceAtomic = this.deroToAtomic ? this.deroToAtomic(priceDero) : Math.floor(priceDero * 100000);
        
        // ART-NFA-MS1 BuyItNow requires SC_ACTION and SC_ID parameters per official documentation
        // Reference: https://github.com/civilware/artificer-nfa-standard/blob/main/ART-NFA-MS1/README.md#buyitnow
        // Note: The docs show BuyItNow with destination in transfers, but we send DERO amount instead
        // Note: callContractEntry automatically adds 'entrypoint', so we don't add it here
        const scRpc = [
            { name: 'SC_ACTION', datatype: 'U', value: 0 },  // Required by ART-NFA-MS1 standard
            { name: 'SC_ID', datatype: 'H', value: normalizedScid }  // Required by ART-NFA-MS1 standard - SCID in hex format
        ];
        
        // BuyItNow requires sending DERO to the contract (price amount)
        // The transfers format for BuyItNow uses destination + burn according to docs
        // But we're using the amount parameter which should send DERO to the contract
        const response = await this.callContractEntry(normalizedScid, 'BuyItNow', scRpc, { amount: priceAtomic });
        
        // Check for contract return value (error codes)
        // NFA BuyItNow typically returns: 0 (success) or error code (> 0)
        const returnValue = response?.result?.value;
        if (returnValue !== undefined && returnValue !== null && returnValue !== 0) {
            const errorMessages = {
                1: 'Listing not found or not active',
                2: 'Price mismatch - offer price does not match listing price',
                3: 'Insufficient DERO sent',
                4: 'Contract not initialized',
                5: 'Listing expired'
            };
            const errorMsg = errorMessages[returnValue] || `Contract returned error code: ${returnValue}`;
            throw new Error(`NFA buy rejected by contract: ${errorMsg}. Your DERO should have been returned to your wallet.`);
        }
        
        return response;
    };

    /* ------------------------------------------------------------------
     * Order management functions
     * ------------------------------------------------------------------ */
    DeroNFTApp.prototype.closeOrdersForAsset = function(scid, tokenId) {
        if (!scid) {
            this.showError?.('Invalid asset SCID');
            return;
        }
        
        // Check if this is an NFA (ART-NFA-MS1)
        // NFAs use their own Start/CancelListing functions
        const asset = this.savedAssets?.find(a => a.scid === scid);
        const isNFA = asset && (asset.type === 'NFA' || asset.contractType === 'ART-NFA-MS1');
        
        if (isNFA) {
            // Use NFA-specific cancellation
            this.cancelNFAListing(scid);
        } else {
            // Use G45 marketplace cancellation
            this._closeOrdersForAssetOnChain(scid, tokenId);
        }
    };

    DeroNFTApp.prototype._closeOrdersForAssetOnChain = async function(scid, tokenId) {
        if (!this.currentAddress || !this.deroWallet || !this.deroWallet.ws) {
            this.showError?.('Please connect your wallet first.');
            return;
        }
        
        try {
            const marketScid = this.ensureG45MarketplaceScid ? this.ensureG45MarketplaceScid(false) : '';
            if (!marketScid || marketScid.length !== 64) {
                this.showError?.('G45 marketplace SCID is not configured.');
                return;
            }
            
            // Query marketplace for active orders
            const scResult = await this.deroWallet.ws.getSC(marketScid);
            const scData = scResult?.result || scResult;
            const stringKeys = scData?.stringkeys || {};
            const uint64Keys = scData?.uint64keys || {};
            
            const decS = (key) => {
                const raw = stringKeys[key];
                if (!raw) return '';
                return this.decodeHexString ? this.decodeHexString(raw) : raw;
            };
            const decU = (key) => {
                if (uint64Keys[key] !== undefined) {
                    const v = parseInt(uint64Keys[key], 10);
                    return Number.isNaN(v) ? 0 : v;
                }
                const raw = stringKeys[key];
                if (!raw) return 0;
                const d = this.decodeHexString ? this.decodeHexString(raw) : raw;
                const p = parseInt(d, 10);
                return Number.isNaN(p) ? 0 : p;
            };
            
            const orderCounter = decU('order_counter');
            const sellCounter = decU('sell_counter');
            const maxOrderId = Math.max(orderCounter || 0, sellCounter || 0);
            const normalizedScid = scid.toLowerCase().trim();
            const currentAddress = this.currentAddress || '';
            
            // Find orders for this asset
            const ordersToClose = [];
            for (let id = 1; id <= maxOrderId; id++) {
                const seller = decS(`sell_order_seller_${id}`);
                const assetScid = decS(`sell_order_asset_${id}`);
                const status = decS(`sell_order_status_${id}`);
                
                if (seller && seller.toLowerCase() === currentAddress.toLowerCase() &&
                    assetScid && assetScid.toLowerCase() === normalizedScid &&
                    status === 'active') {
                    ordersToClose.push(id);
                }
            }
            
            if (ordersToClose.length === 0) {
                this.showNotification?.('No active sell orders found for this asset.', 'info');
                return;
            }
            
            // Close each order
            for (const orderId of ordersToClose) {
                try {
                    const scRpc = [{ name: 'order_id', datatype: 'U', value: orderId }];
                    await this.callContractEntry(marketScid, 'CancelSellOrder', scRpc, {});
                    this.showSuccess?.(`Order ${orderId} cancelled successfully.`);
                } catch (error) {
                    this.showError?.(`Failed to cancel order ${orderId}: ${error.message}`);
                }
            }
            
            // Refresh orders list
            setTimeout(() => {
                if (this.loadSellOrders) {
                    this.loadSellOrders(true);
                }
            }, 2000);
        } catch (error) {
            this.showError?.(`Failed to close orders: ${error.message}`);
        }
    };

    DeroNFTApp.prototype.cancelNFAListing = async function(scid) {
        if (!this.currentAddress || !this.deroWallet || !this.deroWallet.ws) {
            this.showError?.('Please connect your wallet first.');
            return;
        }
        
        const normalizedScid = scid.toLowerCase().trim();
        
        try {
            // Query NFA contract state
            const scResult = await this.deroWallet.ws.getSC(normalizedScid);
            const scData = scResult?.result || scResult;
            const stringKeys = scData?.stringkeys || {};
            const uint64Keys = scData?.uint64keys || {};

            const decS = (key) => {
                const raw = stringKeys[key];
                if (!raw) return '';
                return this.decodeHexString ? this.decodeHexString(raw) : raw;
            };
            const decU = (key) => {
                if (uint64Keys[key] !== undefined) {
                    const v = parseInt(uint64Keys[key], 10);
                    return Number.isNaN(v) ? 0 : v;
                }
                const raw = stringKeys[key];
                if (!raw) return 0;
                const d = this.decodeHexString ? this.decodeHexString(raw) : raw;
                const p = parseInt(d, 10);
                return Number.isNaN(p) ? 0 : p;
            };
            
            const active = decU('active');
            const scBalance = decU('scBalance');
            const listType = decS('listType');
            const ownerRaw = stringKeys['owner']; // Keep raw owner for debugging
            const owner = decS('owner'); // Decoded owner
            const currentAddress = this.currentAddress || '';
            
            const normalizeAddress = (addr) => {
                if (!addr) return '';
                const lower = addr.toLowerCase();
                if (lower.startsWith('dero1')) return lower;
                if (lower.startsWith('deto1')) return 'dero' + lower.substring(4);
                return lower;
            };
            const addressMatches = (addr1, addr2) => {
                if (!addr1 || !addr2) return false;
                const n1 = normalizeAddress(addr1);
                const n2 = normalizeAddress(addr2);
                return n1 === n2 || 
                       addr1.toLowerCase() === addr2.toLowerCase() ||
                       addr1.toLowerCase().substring(0, 20) === addr2.toLowerCase().substring(0, 20);
            };
            
            const isOwner = owner && addressMatches(owner, currentAddress);
            
            
            const hasListing = (active === 1 && scBalance === 1 && (listType === 'sale' || listType === 'auction')) ||
                              (scBalance > 0) || // Asset is escrowed
                              (listType === 'sale' || listType === 'auction'); // Listing exists
            
            if (!hasListing) {
                this.showError(`No listing found. Status: active=${active}, scBalance=${scBalance}, listType=${listType || 'none'}, owner=${owner ? owner.substring(0, 20) + '...' : 'none'}, isOwner=${isOwner}. Use "Query NFA Status" in Wallet Calls tab to debug.`);
                return;
            }
            
            if (!isOwner) {
                // Still try to cancel if asset is escrowed (might be pending confirmation)
                if (scBalance > 0) {
                    this.showNotification('You are not detected as the owner, but the NFA is escrowed. Attempting to cancel. The contract will reject this transaction if you are not the true owner.', 'warning', 0);
                } else {
                    this.showError('You are not the owner of this NFA. Only the owner can cancel listings. The contract will reject this transaction if you are not the owner.');
                    return;
                }
            }
            
            // Try CancelListing first (observes cancelBuffer), fall back to CloseListing
            // The contract will check SIGNER() == owner before allowing cancel
            this.showNotification('Attempting to cancel NFA listing...', 'info');
            try {
                const response = await this.callContractEntry(normalizedScid, 'CancelListing', []);
                const txid = response?.result?.txid;
                this.showSuccess(`NFA listing cancel request sent${txid ? ` (txid: ${txid})` : ''}. Please approve in wallet if prompted.`);
                // Refresh asset status after a delay
                setTimeout(async () => {
                    if (this.loadAssets) {
                        await this.loadAssets(true);
                    }
                }, 2000);
            } catch (errCancel) {
                try {
                    await this.callContractEntry(normalizedScid, 'CloseListing', []);
                    this.showSuccess('NFA listing closed successfully. The escrowed asset will be returned to you.');
                    // Refresh asset status after a delay
                    setTimeout(async () => {
                        if (this.loadAssets) {
                            await this.loadAssets(true);
                        }
                    }, 2000);
                } catch (errClose) {
                    this.showError(`Failed to cancel/close NFA listing: ${errClose.message || errClose}`);
                }
            }
        } catch (error) {
            this.showError(`Failed to cancel NFA listing: ${error.message}`);
        }
    };
}
